
 const player="/Player";

 const addPlayer="/add";

 const editPlayer="/Player/:id";

export default{
player,
addPlayer,
editPlayer
};